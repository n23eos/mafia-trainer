@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 22 or newer is required. Download: https://nodejs.org/en/download
  pause
  exit /b 1
)
for /f "delims=" %%v in ('node -p "process.versions.node.split('.')[0]" 2^>nul') do set "NODE_MAJOR=%%v"
if not defined NODE_MAJOR (
  echo Could not read the Node.js version. Node.js 22 or newer is required.
  pause
  exit /b 1
)
if %NODE_MAJOR% LSS 22 (
  echo Node.js 22 or newer is required. Download: https://nodejs.org/en/download
  pause
  exit /b 1
)
node launcher.mjs
if errorlevel 1 pause
