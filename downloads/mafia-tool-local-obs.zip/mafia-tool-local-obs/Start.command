#!/bin/sh
cd "$(dirname "$0")" || exit 1
if ! command -v node >/dev/null 2>&1; then
  echo "Node.js 22 or newer is required. Download: https://nodejs.org/en/download" >&2
  exit 1
fi
node_major=$(node -p "process.versions.node.split('.')[0]" 2>/dev/null)
case "$node_major" in
  ''|*[!0-9]*) echo "Could not read the Node.js version. Node.js 22 or newer is required." >&2; exit 1 ;;
esac
if [ "$node_major" -lt 22 ]; then
  echo "Node.js 22 or newer is required. Download: https://nodejs.org/en/download" >&2
  exit 1
fi
exec node launcher.mjs
