import {spawn} from 'node:child_process';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createLocalBroadcastServer} from './local-broadcast-server.mjs';

const nodeMajor=Number.parseInt(process.versions.node.split('.')[0],10);
if(!Number.isInteger(nodeMajor)||nodeMajor<22){
  console.error('Нужен Node.js 22 или новее: https://nodejs.org/en/download');
  process.exit(1);
}

function openBrowser(url){
  if(process.env.MAFIA_NO_BROWSER==='1')return;
  const command=process.platform==='darwin'?'open':process.platform==='win32'?'cmd.exe':'xdg-open';
  const args=process.platform==='win32'?['/d','/s','/c','start','',url]:[url];
  try{const child=spawn(command,args,{detached:true,stdio:'ignore'});child.once('error',()=>{});child.unref();}catch{}
}

function readPort(args){
  if(args.length===0)return 8780;
  if(args.length!==2||args[0]!=='--port')throw Error('Использование: node launcher.mjs [--port 8780]');
  const port=Number(args[1]);
  if(!Number.isInteger(port)||port<0||port>65535)throw Error('Порт должен быть целым числом от 0 до 65535.');
  return port;
}

const host='127.0.0.1';
let port;
try{port=readPort(process.argv.slice(2));}
catch(error){console.error(error.message);process.exitCode=1;}

if(port!==undefined){
  const root=path.join(path.dirname(fileURLToPath(import.meta.url)),'app');
  const server=createLocalBroadcastServer({root,host,port});
  let closing=false;
  const removeSignals=()=>{process.removeListener('SIGINT',stop);process.removeListener('SIGTERM',stop);};
  const stop=()=>{
    if(closing)return;
    closing=true;
    removeSignals();
    if(server.listening)server.close(error=>{if(error){console.error('Не удалось остановить локальный экран:',error.message);process.exitCode=1;}});
  };
  process.once('SIGINT',stop);
  process.once('SIGTERM',stop);
  server.once('error',error=>{
    removeSignals();
    if(error.code==='EADDRINUSE')console.error(`Порт ${port} занят. Закройте другую копию или запустите node launcher.mjs --port 8781.`);
    else console.error('Не удалось запустить локальный экран:',error.message);
    process.exitCode=1;
  });
  server.listen(port,host,()=>{
    const address=server.address();
    const actualPort=address&&typeof address==='object'?address.port:port;
    const url=`http://${host}:${actualPort}`;
    console.log(`Локальный экран OBS готов: ${url}`);
    console.log('Для остановки нажмите Ctrl+C.');
    openBrowser(url);
  });
}
