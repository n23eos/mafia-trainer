import {createHash,randomBytes,randomUUID,timingSafeEqual} from 'node:crypto';
import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import {pathToFileURL} from 'node:url';

const DEFAULT_HOST='127.0.0.1';
const DEFAULT_PORT=8780;
const MAX_BODY_BYTES=320*1024;
const MAX_ACTIVE_CHANNELS=8;
const MAX_RETAINED_CHANNELS=64;
const MAX_AVATARS_PER_CHANNEL=60;
const STALE_MS=5000;
const EXPIRES_MS=24*60*60*1000;
const UUID=/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const AVATAR_ID=/^[0-9a-f]{64}$/;
const TOKEN=/^[A-Za-z0-9_-]{20,256}$/;
const STATIC_EXTENSIONS=new Set(['.css','.html','.ico','.js','.json','.mp3','.png','.svg','.txt','.webmanifest','.webp','.woff2','.xml']);
const MIME_TYPES={
  '.css':'text/css; charset=utf-8','.html':'text/html; charset=utf-8','.ico':'image/x-icon',
  '.js':'text/javascript; charset=utf-8','.json':'application/json; charset=utf-8',
  '.mp3':'audio/mpeg','.png':'image/png','.svg':'image/svg+xml; charset=utf-8',
  '.txt':'text/plain; charset=utf-8','.webmanifest':'application/manifest+json; charset=utf-8',
  '.webp':'image/webp','.woff2':'font/woff2','.xml':'application/xml; charset=utf-8'
};
const POLICY_FIELDS=[
  'numbers','names','statuses','exitReasons','roles','sheriffChecks','donChecks',
  'fouls','candidates','votes','speaker','timer','phase','avatars'
];
const WRITE_RPCS=new Set(['obs_create','obs_publish','obs_status','obs_revoke','obs_revoke_stale','obs_avatar_upload']);
const READ_RPCS=new Set(['obs_read','obs_avatar_read']);

function rpcError(code,message,status){
  const error=new Error(message);
  error.code=code;
  error.status=status??(code==='42501'?403:code==='40001'?409:400);
  return error;
}

function object(value){return value!==null&&typeof value==='object'&&!Array.isArray(value);}
function textLength(value){return typeof value==='string'?[...value].length:-1;}
function integer(value,min,max){return Number.isSafeInteger(value)&&value>=min&&value<=max;}
function sha256(value){return createHash('sha256').update(value).digest('hex');}
function jsonBytes(value){return Buffer.byteLength(JSON.stringify(value));}
function secureEqual(left,right){
  if(typeof left!=='string'||typeof right!=='string')return false;
  const a=Buffer.from(left),b=Buffer.from(right);
  return a.length===b.length&&timingSafeEqual(a,b);
}

function normalizePolicy(value){
  if(!object(value)||jsonBytes(value)>16384)throw rpcError('22023','Invalid OBS visibility policy');
  if(!['hidden','open','custom'].includes(value.mode)||!['none','all','eliminated'].includes(value.roleVisibility)||!object(value.fields))throw rpcError('22023','Invalid OBS visibility policy');
  for(const field of POLICY_FIELDS){
    if(field==='avatars'&&value.fields[field]===undefined)continue;
    if(typeof value.fields[field]!=='boolean')throw rpcError('22023',`Invalid OBS visibility policy field: ${field}`);
  }
  const fields=Object.fromEntries(POLICY_FIELDS.map(field=>[field,value.fields[field]===true]));
  let roleVisibility=value.roleVisibility;
  if(value.mode==='hidden'){
    roleVisibility='none';fields.roles=false;fields.sheriffChecks=false;fields.donChecks=false;
  }else if(value.mode==='open'){
    roleVisibility='all';fields.roles=true;
  }else if(!fields.roles||roleVisibility==='none'){
    roleVisibility='none';fields.roles=false;
  }else if(roleVisibility==='eliminated')fields.statuses=true;
  return{mode:value.mode,roleVisibility,fields};
}

function buildProjection(policyValue,snapshot,gameId,revision,publishedAt,avatars){
  const policy=normalizePolicy(policyValue);
  if(!object(snapshot)||jsonBytes(snapshot)>262144||snapshot.schemaVersion!==2||snapshot.kind!=='obs-overlay'||snapshot.gameId!==gameId||!['sports','urban'].includes(snapshot.mode)||!['ru','en'].includes(snapshot.lang)||!Array.isArray(snapshot.players)||snapshot.players.length>30)throw rpcError('22023','Invalid OBS snapshot');
  const ids=new Set(),seats=new Set(),players=[];
  for(const player of snapshot.players){
    if(!object(player)||textLength(player.id)<1||textLength(player.id)>128||ids.has(player.id))throw rpcError('22023','Invalid or duplicate OBS player id');
    ids.add(player.id);
    if(player.seat!==undefined&&(!integer(player.seat,1,30)||seats.has(player.seat)))throw rpcError('22023','Invalid OBS player seat');
    if(player.seat!==undefined)seats.add(player.seat);
    if(player.name!==undefined&&(typeof player.name!=='string'||textLength(player.name)>40))throw rpcError('22023','Invalid OBS player name');
    if(player.status!==undefined&&(!['alive','out','voted','shot','removed'].includes(player.status)))throw rpcError('22023','Invalid OBS player status');
    if(player.fouls!==undefined&&!integer(player.fouls,0,20))throw rpcError('22023','Invalid OBS player fouls');
    if(player.role!==undefined&&(!object(player.role)||typeof player.role.label!=='string'||typeof player.role.team!=='string'||textLength(player.role.label)>40||textLength(player.role.team)>40))throw rpcError('22023','Invalid OBS player role');
    if(player.avatarId!==undefined&&(typeof player.avatarId!=='string'||!AVATAR_ID.test(player.avatarId)))throw rpcError('22023','Invalid OBS player avatar');
    if(player.avatarId!==undefined&&!avatars.has(player.avatarId))throw rpcError('22023','OBS avatar does not belong to channel');
    const output={id:player.id};
    if(policy.fields.numbers&&player.seat!==undefined)output.seat=player.seat;
    if(policy.fields.names&&player.name!==undefined)output.name=player.name;
    if(policy.fields.statuses&&player.status!==undefined)output.status=policy.fields.exitReasons||player.status==='alive'?player.status:'out';
    if(policy.fields.fouls&&player.fouls!==undefined)output.fouls=player.fouls;
    if(policy.fields.roles&&player.role!==undefined&&(policy.roleVisibility==='all'||policy.roleVisibility==='eliminated'&&player.status!==undefined&&player.status!=='alive'))output.role={label:player.role.label,team:player.role.team};
    if(policy.fields.avatars&&player.avatarId!==undefined)output.avatarId=player.avatarId;
    players.push(output);
  }
  const output={schemaVersion:2,kind:'obs-overlay',gameId,mode:snapshot.mode,revision,updatedAt:new Date(publishedAt).toISOString(),lang:snapshot.lang,players};
  if(['grid','portraits'].includes(snapshot.layout))output.layout=snapshot.layout;
  if(snapshot.phase!==undefined){
    if(!object(snapshot.phase)||typeof snapshot.phase.label!=='string'||textLength(snapshot.phase.label)>80||!integer(snapshot.phase.day,0,999))throw rpcError('22023','Invalid OBS phase');
    if(policy.fields.phase)output.phase={label:snapshot.phase.label,day:snapshot.phase.day};
  }
  if(snapshot.speakerId!==undefined){
    if(snapshot.speakerId!==null&&(typeof snapshot.speakerId!=='string'||!ids.has(snapshot.speakerId)))throw rpcError('22023','Invalid OBS speaker');
    if(policy.fields.speaker)output.speakerId=snapshot.speakerId;
  }
  if(snapshot.timer!==undefined){
    if(!object(snapshot.timer)||!integer(snapshot.timer.remaining,0,86400)||typeof snapshot.timer.running!=='boolean'||!(snapshot.timer.endAt===null||integer(snapshot.timer.endAt,0,Number.MAX_SAFE_INTEGER)))throw rpcError('22023','Invalid OBS timer');
    if(policy.fields.timer)output.timer={remaining:snapshot.timer.remaining,running:snapshot.timer.running,endAt:snapshot.timer.endAt};
  }
  if(snapshot.candidates!==undefined){
    if(!Array.isArray(snapshot.candidates)||snapshot.candidates.length>30)throw rpcError('22023','Invalid OBS candidates');
    const seen=new Set();
    for(const id of snapshot.candidates)if(typeof id!=='string'||!ids.has(id)||seen.has(id))throw rpcError('22023','Unknown or duplicate OBS candidate');else seen.add(id);
    if(policy.fields.candidates)output.candidates=[...snapshot.candidates];
  }
  if(snapshot.votes!==undefined){
    if(!Array.isArray(snapshot.votes)||snapshot.votes.length>30)throw rpcError('22023','Invalid OBS votes');
    const seen=new Set(),votes=[];
    for(const vote of snapshot.votes){
      if(!object(vote)||typeof vote.id!=='string'||!ids.has(vote.id)||seen.has(vote.id)||!integer(vote.count,0,30))throw rpcError('22023','Invalid OBS vote');
      seen.add(vote.id);votes.push({id:vote.id,count:vote.count});
    }
    if(policy.fields.votes)output.votes=votes;
  }
  if(snapshot.checks!==undefined){
    if(!Array.isArray(snapshot.checks)||snapshot.checks.length>100)throw rpcError('22023','Invalid OBS checks');
    const checks=[];
    for(const check of snapshot.checks){
      if(!object(check)||!['sheriff','don'].includes(check.kind)||!integer(check.night,0,999)||typeof check.targetId!=='string'||!ids.has(check.targetId)||typeof check.result!=='string'||textLength(check.result)>80)throw rpcError('22023','Invalid OBS check');
      if(check.kind==='sheriff'&&policy.fields.sheriffChecks||check.kind==='don'&&policy.fields.donChecks)checks.push({kind:check.kind,night:check.night,targetId:check.targetId,result:check.result});
    }
    if(policy.fields.sheriffChecks||policy.fields.donChecks)output.checks=checks;
  }
  return{policy,snapshot:output};
}

function sendJson(response,status,value){
  const body=JSON.stringify(value);
  response.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Content-Length':Buffer.byteLength(body),'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});
  response.end(body);
}

function sendError(response,error){
  const status=Number.isInteger(error?.status)?error.status:500;
  sendJson(response,status,{code:error?.code||'LOCAL_SERVER_ERROR',message:status===500?'Local broadcast server error':error.message});
}

function readJson(request){
  return new Promise((resolve,reject)=>{
    const contentType=String(request.headers['content-type']||'').split(';',1)[0].trim().toLowerCase();
    if(contentType!=='application/json'){reject(rpcError('22023','JSON body required',415));return;}
    const declared=Number(request.headers['content-length']);
    if(Number.isFinite(declared)&&declared>MAX_BODY_BYTES){request.resume();reject(rpcError('22023','Request body too large',413));return;}
    const chunks=[];let size=0,settled=false;
    request.on('data',chunk=>{
      if(settled)return;
      size+=chunk.length;
      if(size>MAX_BODY_BYTES){settled=true;request.resume();reject(rpcError('22023','Request body too large',413));return;}
      chunks.push(chunk);
    });
    request.on('end',()=>{
      if(settled)return;
      try{const value=JSON.parse(Buffer.concat(chunks).toString('utf8'));if(!object(value))throw Error();resolve(value);}
      catch{reject(rpcError('22023','Invalid JSON body'));}
    });
    request.on('error',error=>{if(!settled)reject(error);});
  });
}

function safeStaticFile(root,requestUrl){
  const rawPath=String(requestUrl||'').split(/[?#]/,1)[0];
  let decoded;
  try{decoded=decodeURIComponent(rawPath);}catch{return null;}
  if(decoded.includes('\\')||decoded.includes('\0')||decoded.includes('%'))return null;
  const relative=decoded==='/'?'index.html':decoded.replace(/^\/+/, '');
  const parts=relative.split('/');
  if(parts.some(part=>!part||part==='.'||part==='..'||part==='!notes'||part.startsWith('.')||!/^[A-Za-z0-9][A-Za-z0-9._-]*$/.test(part)))return null;
  if(!STATIC_EXTENSIONS.has(path.extname(relative).toLowerCase()))return null;
  let current=root;
  try{
    for(const part of parts){current=path.join(current,part);const stat=fs.lstatSync(current);if(stat.isSymbolicLink())return null;}
    const stat=fs.statSync(current);
    if(!stat.isFile())return null;
    return{path:current,size:stat.size,extension:path.extname(current).toLowerCase()};
  }catch{return null;}
}

export function createLocalBroadcastServer({root=path.resolve('.local-broadcast'),host=DEFAULT_HOST,port=DEFAULT_PORT,now=()=>Date.now()}={}){
  if(host!==DEFAULT_HOST)throw Error('Local broadcast server must bind to 127.0.0.1');
  const absoluteRoot=path.resolve(root);
  if(fs.existsSync(absoluteRoot)&&fs.lstatSync(absoluteRoot).isSymbolicLink())throw Error('Local broadcast root cannot be a symlink');
  const ownerId=randomUUID(),writeToken=randomBytes(32).toString('base64url'),channels=new Map();

  const time=()=>{const value=Number(now());if(!Number.isFinite(value))throw Error('Invalid server clock');return value;};
  const revoke=channel=>{channel.revokedAt=time();channel.snapshot=null;channel.policy=null;channel.lastCommandId=null;channel.lastResponse=null;channel.updatedAt=channel.revokedAt;channel.avatars.clear();};
  const cleanup=()=>{
    const current=time();
    for(const channel of channels.values())if(!channel.revokedAt&&channel.expiresAt<=current)revoke(channel);
    if(channels.size<=MAX_RETAINED_CHANNELS)return;
    const removable=[...channels.values()].filter(channel=>channel.revokedAt||channel.expiresAt<=current).sort((a,b)=>a.updatedAt-b.updatedAt);
    while(channels.size>MAX_RETAINED_CHANNELS&&removable.length)channels.delete(removable.shift().id);
  };
  const channelForWrite=id=>{
    const channel=typeof id==='string'?channels.get(id):null,current=time();
    if(!channel||channel.revokedAt||channel.expiresAt<=current)throw rpcError('42501','OBS channel access denied');
    return channel;
  };
  const rpc={
    obs_create(args){
      const gameId=typeof args.p_game_id==='string'?args.p_game_id.trim():'';
      if(textLength(gameId)<1||textLength(gameId)>128)throw rpcError('22023','Invalid game id');
      cleanup();const current=time();
      for(const channel of channels.values())if(!channel.revokedAt&&channel.expiresAt>current&&current-channel.updatedAt>60000)revoke(channel);
      const active=[...channels.values()].filter(channel=>!channel.revokedAt&&channel.expiresAt>current);
      if(active.length>=MAX_ACTIVE_CHANNELS)throw rpcError('22023','Active OBS channel limit reached');
      const channel={id:randomUUID(),gameId,token:randomBytes(32).toString('base64url'),revision:0,policy:null,snapshot:null,lastCommandId:null,lastResponse:null,createdAt:current,updatedAt:current,expiresAt:current+EXPIRES_MS,revokedAt:null,avatars:new Map()};
      channels.set(channel.id,channel);cleanup();
      return{id:channel.id,token:channel.token,revision:0};
    },
    obs_status(args){
      const channel=channelForWrite(args.p_channel_id),current=time();
      return{revision:channel.revision,commandId:channel.lastCommandId,updatedAt:new Date(channel.updatedAt).toISOString(),stale:current-channel.updatedAt>STALE_MS};
    },
    obs_publish(args){
      if(!UUID.test(String(args.p_command_id||''))||!integer(args.p_expected_revision,0,Number.MAX_SAFE_INTEGER))throw rpcError('22023','Invalid OBS publish command');
      const channel=channelForWrite(args.p_channel_id);
      if(channel.lastCommandId===args.p_command_id)return structuredClone(channel.lastResponse);
      if(channel.revision!==args.p_expected_revision)throw rpcError('40001','CONFLICT: OBS channel revision changed');
      const current=time(),revision=channel.revision+1,built=buildProjection(args.p_policy,args.p_snapshot,channel.gameId,revision,current,channel.avatars);
      const response={revision,updatedAt:built.snapshot.updatedAt,snapshot:built.snapshot};
      channel.revision=revision;channel.policy=built.policy;channel.snapshot=built.snapshot;channel.updatedAt=current;channel.lastCommandId=args.p_command_id;channel.lastResponse=response;
      const referenced=new Set(args.p_snapshot.players.flatMap(player=>typeof player?.avatarId==='string'?[player.avatarId]:[]));
      for(const avatarId of channel.avatars.keys())if(!referenced.has(avatarId))channel.avatars.delete(avatarId);
      return structuredClone(response);
    },
    obs_read(args){
      if(typeof args.p_channel_id!=='string'||typeof args.p_token!=='string'||!TOKEN.test(args.p_token))return null;
      const channel=channels.get(args.p_channel_id),current=time();
      if(!channel||channel.revokedAt||channel.expiresAt<=current||!secureEqual(args.p_token,channel.token))return null;
      return{revision:channel.revision,updatedAt:new Date(channel.snapshot?channel.updatedAt:channel.updatedAt).toISOString(),snapshot:channel.snapshot&&current-channel.updatedAt<=STALE_MS?structuredClone(channel.snapshot):null};
    },
    obs_revoke(args){const channel=channels.get(args.p_channel_id);if(!channel)throw rpcError('42501','OBS channel access denied');if(!channel.revokedAt)revoke(channel);return{ok:true};},
    obs_revoke_stale(args){
      const channel=channels.get(args.p_channel_id);if(!channel)throw rpcError('42501','OBS channel access denied');
      if(channel.revokedAt)return{ok:true,revoked:true};
      if(time()-channel.updatedAt<=STALE_MS)return{ok:true,revoked:false};
      revoke(channel);return{ok:true,revoked:true};
    },
    obs_avatar_upload(args){
      const channel=channelForWrite(args.p_channel_id),dataUrl=args.p_data_url;
      if(typeof dataUrl!=='string'||!/^data:image\/jpeg;base64,[A-Za-z0-9+/]+={0,2}$/.test(dataUrl)||dataUrl.length<27||dataUrl.length>43715)throw rpcError('22023','Invalid OBS avatar data URL');
      const encoded=dataUrl.slice(23);if(encoded.length%4!==0)throw rpcError('22023','Invalid OBS avatar base64');
      const jpeg=Buffer.from(encoded,'base64');
      if(jpeg.toString('base64')!==encoded||jpeg.length<4||jpeg.length>32768||jpeg[0]!==0xff||jpeg[1]!==0xd8||jpeg.at(-2)!==0xff||jpeg.at(-1)!==0xd9)throw rpcError('22023','Invalid OBS avatar JPEG');
      const avatarId=sha256(jpeg);if(channel.avatars.has(avatarId))return{avatarId};
      if(channel.avatars.size>=MAX_AVATARS_PER_CHANNEL)throw rpcError('22023','OBS avatar asset limit reached');
      channel.avatars.set(avatarId,jpeg);return{avatarId};
    },
    obs_avatar_read(args){
      const channel=channels.get(args.p_channel_id),current=time();
      if(!channel||channel.revokedAt||channel.expiresAt<=current||typeof args.p_token!=='string'||!TOKEN.test(args.p_token)||!secureEqual(args.p_token,channel.token)||typeof args.p_avatar_id!=='string'||!AVATAR_ID.test(args.p_avatar_id)||!channel.snapshot||current-channel.updatedAt>STALE_MS)return null;
      if(!channel.snapshot.players.some(player=>player.avatarId===args.p_avatar_id))return null;
      const jpeg=channel.avatars.get(args.p_avatar_id);return jpeg?{dataUrl:`data:image/jpeg;base64,${jpeg.toString('base64')}`}:null;
    }
  };

  let cleanupTimer;
  const server=http.createServer(async(request,response)=>{
    try{
      const address=server.address();
      if(!address||typeof address==='string')throw rpcError('HOST_REJECTED','Server is not listening',400);
      const expectedHost=`${address.address}:${address.port}`,requestHost=String(request.headers.host||'').toLowerCase();
      if(requestHost!==expectedHost.toLowerCase())throw rpcError('HOST_REJECTED','Invalid Host header',403);
      const ownOrigin=`http://${expectedHost}`,origin=request.headers.origin;
      if(origin!==undefined&&origin!==ownOrigin)throw rpcError('ORIGIN_REJECTED','Cross-origin requests are not allowed',403);
      if(String(request.headers['sec-fetch-site']||'').toLowerCase()==='cross-site')throw rpcError('ORIGIN_REJECTED','Cross-site requests are not allowed',403);
      const pathname=new URL(request.url,ownOrigin).pathname;
      if(pathname==='/__local-broadcast/session'){
        if(request.method!=='GET')throw rpcError('METHOD_NOT_ALLOWED','Method not allowed',405);
        if(request.headers['x-mafia-local']!=='1')throw rpcError('42501','Local page authorization required');
        sendJson(response,200,{ownerId,writeToken});return;
      }
      const match=pathname.match(/^\/__local-broadcast\/rpc\/([a-z_]+)$/);
      if(match){
        if(request.method!=='POST')throw rpcError('METHOD_NOT_ALLOWED','Method not allowed',405);
        const name=match[1];if(!WRITE_RPCS.has(name)&&!READ_RPCS.has(name))throw rpcError('NOT_FOUND','RPC not found',404);
        if(WRITE_RPCS.has(name)&&!secureEqual(request.headers['x-mafia-write'],writeToken))throw rpcError('42501','Invalid local write token');
        const args=await readJson(request),result=rpc[name](args);sendJson(response,200,result);return;
      }
      if(!['GET','HEAD'].includes(request.method))throw rpcError('METHOD_NOT_ALLOWED','Method not allowed',405);
      const file=safeStaticFile(absoluteRoot,request.url);
      if(!file)throw rpcError('NOT_FOUND','File not found',404);
      response.writeHead(200,{'Content-Type':MIME_TYPES[file.extension]||'application/octet-stream','Content-Length':file.size,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer'});
      if(request.method==='HEAD'){response.end();return;}
      const stream=fs.createReadStream(file.path);stream.on('error',error=>response.destroy(error));stream.pipe(response);
    }catch(error){if(!response.headersSent)sendError(response,error);else response.destroy();}
  });
  server.localBroadcast={ownerId,writeToken,host,port,root:absoluteRoot};
  server.on('listening',()=>{cleanupTimer=setInterval(cleanup,30000);cleanupTimer.unref();});
  server.on('close',()=>clearInterval(cleanupTimer));
  return server;
}

if(process.argv[1]&&import.meta.url===pathToFileURL(path.resolve(process.argv[1])).href){
  const root=path.resolve(process.env.MAFIA_OUTPUT_DIR||'.local-broadcast');
  const server=createLocalBroadcastServer({root});
  server.listen(DEFAULT_PORT,DEFAULT_HOST,()=>console.log(`Mafia local broadcast: http://${DEFAULT_HOST}:${DEFAULT_PORT}`));
}
